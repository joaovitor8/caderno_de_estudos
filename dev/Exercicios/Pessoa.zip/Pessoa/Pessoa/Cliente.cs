﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pessoa
{
    public class Cliente
    {
		public Cliente()
		{
			this.nome = "";
            this.sobrenome = "";
            this.cpf = 0;
		}

        //-----------------------------------------------------------------------------------------

        private string nome;

		public string Nome
		{
			get { return nome; }
			set { nome = value; }
		}

		//-----------------------------------------------------------------------------------------

		private string sobrenome;

		public string Sobrenome
		{
			get { return sobrenome; }
			set { sobrenome = value; }
		}

		//-----------------------------------------------------------------------------------------

		private double cpf;

		public double Cpf
		{
			get { return cpf; }
			set { cpf = value; }
		}

        //-----------------------------------------------------------------------------------------

		public void ValidarCPF()
		{
			if (Cpf <= 0)
			{
				bool validar = false;
				Console.WriteLine("CPF invalido, tente novamente.  -  {0}", validar);
			}
			else if (Cpf > 0)
			{
				bool validar = true;
                Console.WriteLine("CPF valido.  -  {0}", validar);
            }
		}

    }
}
