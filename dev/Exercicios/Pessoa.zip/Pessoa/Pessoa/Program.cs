﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pessoa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cliente c = new Cliente();

            Console.Write("Informe seu nome: ");
            c.Nome = Console.ReadLine();

            Console.Write("Informe seu sobrenome: ");
            c.Sobrenome = Console.ReadLine();

            Console.Write("Informe seu CPF: ");
            c.Cpf = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Nome: {0}", c.Nome);
            Console.WriteLine("Sobrenome: {0}", c.Sobrenome);
            Console.WriteLine("CPF: {0}", c.Cpf);

            c.ValidarCPF();


            Console.ReadKey();
        }
    }
}
